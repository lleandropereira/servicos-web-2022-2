package br.edu.ifsc.atividade;

public class Atividade {

}
