package br.edu.ifsc.atividade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade4ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Atividade4ApiApplication.class, args);
	}

}
