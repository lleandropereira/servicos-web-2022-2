package br.edu.ifsc.atividade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade4ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
