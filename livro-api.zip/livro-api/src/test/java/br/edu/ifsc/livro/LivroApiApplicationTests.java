package br.edu.ifsc.livro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivroApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
